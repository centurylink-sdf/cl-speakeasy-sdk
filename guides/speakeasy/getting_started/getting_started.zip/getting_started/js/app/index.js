define(['CtlApiLoader'], function(Ctl) {

    console.log('Running CtlApi v' + Ctl.getVersion());

    if (Ctl.Auth.isAuthenticated()) {
        console.log('already authenticated, we can load Speak Easy now');
        loadSpeakEasy();
    } else {
        Ctl.Auth.login('andrew@consumer', 'Password@1234', function(error, response) {
            if (!error && response) {
                console.info('Successfully authenticated. Exposing subscription services selection.');
                var product = populateSubscriptionServices(response);
                Ctl.Auth.setDefaultSubscriptionService(product.serviceName, product.publicId, function(error, response) {
                    if (!error && response) {
                        console.info('Successfully set default service.');
                        loadSpeakEasy();
                    } else {
                        console.error('Service subscription details retrieval failed: ', error);
                    }

                });

            } else {
                console.error('Authentication failed: ', error);
            }
        });
    }

    function populateSubscriptionServices(services) {
        var publicIds = Object.keys(services);
        for (var val in services) {
            if(services.hasOwnProperty(val)) {
                for (var serviceName in services[val]) {
                    if(services[val].hasOwnProperty(serviceName)) {
                        return {
                            publicId: val,
                            serviceName: services[val][serviceName]
                        };
                    }
                }
            }
        }
    }

    function loadSpeakEasy() {
        Ctl.load('SpeakEasy', '0.1.4', function(err, speakEasy) {
            if (err) {
                console.log('Error loading SpeakEasy', err);
            } else {
                console.log('Running SpeakEasy v' + speakEasy.version());
                setupSpeakEasy(speakEasy);
                makeCall(speakEasy);
            }
        });
    }

    function setupSpeakEasy(speakEasy) {
        speakEasy.CallManager.setup({
            localVideoContainer: 'localVideo',
            remoteVideoContainer: 'remoteVideo'
        });
    }

    function makeCall(speakEasy) {
        speakEasy.CallManager.createCall('3183601227', false, function(call) {
            attachCallListeners(call);
        }, function() {
            console.log('Make new call failed!');
        });
    }

    function attachCallListeners(call) {

        call.on('CALL_RINGING', function() {
            console.log('Ringing!');
        });

        call.on('CALL_STARTED', function() {
            console.log('Call is started!');
        });

        call.on('CALL_ENDED', function() {
            console.log('Call was ended on other side!');
        });

        call.on('CALL_HELD', function() {
            console.log('Call is held!');
        });

        call.on('CALL_REMOTE_HELD', function() {
            console.log('Call was held on other side!');
        });

        call.on('CALL_REJECTED', function() {
            console.log('Call was rejected!');
        });

    }
});
