require(['./common'], function (common) {
    require(['app/index']);
});
