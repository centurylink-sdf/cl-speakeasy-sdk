var CtlSpeakEasy = SpeakEasy;

console.log('SpeakEasy has been loaded');
console.log('Running SpeakEasy v' + CtlSpeakEasy.version());

var btnLogin = $('.btn-login');
var btnLogout = $('.btn-logout');

// For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.Auth-method-isAuthenticated
if (CtlSpeakEasy.Auth.isAuthenticated()) {
    initSpeakEasy();
} else {
    window.location.href = 'index.html';
}

function initSpeakEasy() {

    CtlSpeakEasy.init(null, null, null, function() {

        // For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.Auth-method-getLoginUsername
        var userName = CtlSpeakEasy.Auth.getLoginUsername();

        $('#userName').html(userName);

        var confDestination = document.getElementById('confDestination');
        var btnMakeCall = document.getElementById('btnMakeCall');
        var btnEndCall = document.getElementById('btnEndCall');
        var btnStartVideo = document.getElementById('btnStartVideo');
        var btnStopVideo = document.getElementById('btnStopVideo');
        var btnHoldCall = document.getElementById('btnHoldCall');
        var btnUnHoldCall = document.getElementById('btnUnHoldCall');
        var btnMute = document.getElementById('btnMute');
        var btnUnMute = document.getElementById('btnUnMute');

        var btnLogout = document.getElementById('btnLogout');

        // For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.speakeasy.CallManager-method-setup
        CtlSpeakEasy.CallManager.setup(
            {
                localVideoContainer: 'localVideo',
                remoteVideoContainer: 'remoteVideo'
            }
        );

        btnMakeCall.addEventListener('click', function (e) {
            var numToCall = confDestination.value;

            $('#btnGroupCall').show();
            confDestination.value = '';

            // For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.speakeasy.CallManager-method-createCall
            CtlSpeakEasy.CallManager.createCall(numToCall, false, function(call) {
                updateCallButtonsGroup();
                attachCallListeners(call);
                addCall(call.getCallId(), { name: '', number: numToCall, status: 'Ringing' });
            }, function() {
                showErrorMessage('Make new call failed!');
            });
        });

    });
}

function updateCallStatus(callId, status) {

    var $callRow = $('#currentCalls').find('tr[data-id="'+callId+'"]');
    $callRow.find('.js-status').text(status);
}

function removeCall(callId) {
    var $callRow = $('#currentCalls').find('tr[data-id="'+callId+'"]');
    $callRow.remove();

    // For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.speakeasy.CallManager-method-getCallsCount
    if(CtlSpeakEasy.CallManager.getCallsCount() === 0) {
        $('#noCallsRow').show();
    }
}

function updateCallButtonsGroup() {

    var callsCount = CtlSpeakEasy.CallManager.getCallsCount();

    if(callsCount > 0) {
        var call = CtlSpeakEasy.CallManager.getCurrentCall();

        if(call.isMuted) {
            $(btnMute).hide();
            $(btnUnMute).show();
        }
        else {
            $(btnUnMute).hide();
            $(btnMute).show();
        }

        if(call.isVideoStarted) {
            $(btnStartVideo).hide();
            $(btnStopVideo).show();
            $('#localVideoContainer').show();
        }
        else {
            $('#localVideoContainer').hide();
            $(btnStopVideo).hide();
            $(btnStartVideo).show();
        }

        if(call.isOnHold()) {
            $(btnHoldCall).hide();
            $(btnUnHoldCall).show();
        }
        else {
            $(btnUnHoldCall).hide();
            $(btnHoldCall).show();
        }

        $('#btnGroupCall').show();
    }
    else {
        $('#btnGroupCall').hide();
    }
}

function attachCallListeners(call) {

    var callId = call.getCallId();

    // For more info reference to http://[documentation-domain]/docs/#!/api/Ctl.speakeasy.BaseCall-method-on
    call.on('CALL_RINGING', function() {
        showInfoMessage('Ringing!');
        updateCallStatus(callId, 'Ringing');
    });

    call.on('CALL_STARTED', function() {
        showInfoMessage('Call is started!');
        updateCallStatus(callId, 'In Call');
        updateCallButtonsGroup();
    });

    call.on('CALL_ENDED', function() {
        showInfoMessage('Call was ended on other side!');

        updateCallStatus(callId, 'Ended');
        setTimeout(function() {
            removeCall(callId);
        }, 1000);

        updateCallButtonsGroup();
    });

    call.on('CALL_HELD', function() {
        showInfoMessage('Call is held!');
        updateCallStatus(callId, 'Hold');
    });

    call.on('CALL_REMOTE_HELD', function() {
        showInfoMessage('Call was held on other side!');
        updateCallStatus(callId, 'Remote hold');
        updateCallButtonsGroup();
    });

    call.on('CALL_REJECTED', function() {
        showInfoMessage('Call was rejected!');
        updateCallStatus(callId, 'Rejected');
        updateCallButtonsGroup();
        setTimeout(function() {
            removeCall(callId);
        }, 1000);
    });

}

// Utility functions to show error|info|success|warning messages
function showErrorMessage(msg) {
    showMessage(msg, 'alert alert-danger');
}

function showInfoMessage(msg) {
    showMessage(msg, 'alert alert-info');
}

function showSuccessMessage(msg) {
    showMessage(msg, 'alert alert-success');
}

function showWarningMessage(msg) {
    showMessage(msg, 'alert alert-warning');
}

function showMessage(msg, classNames) {
    var logContainer = document.getElementById('logContainer');
    var elChild = document.createElement('div');
    elChild.className = classNames;
    elChild.innerHTML = msg;
    logContainer.insertBefore(elChild, logContainer.firstChild);
}
