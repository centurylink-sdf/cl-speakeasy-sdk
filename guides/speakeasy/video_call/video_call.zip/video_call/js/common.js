require.config({
    baseUrl: "js/lib",
    paths: {
      "app": "../app",
      "CtlApiLoader": "lib/ctlapi"
    }
});
