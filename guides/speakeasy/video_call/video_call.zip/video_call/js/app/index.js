define(['CtlApiLoader'], function(Ctl) {

    console.log('Running CtlApi v' + Ctl.getVersion());

    if (Ctl.Auth.isAuthenticated()) {
        console.log('already authenticated, we can load Speak Easy now');
        loadSpeakEasy();
    } else {
        Ctl.Auth.login('andrew@consumer', 'Password@1234', function(error, response) {
            if (!error && response) {
                console.info('Successfully authenticated. Exposing subscription services selection.');
                var product = populateSubscriptionServices(response);
                Ctl.Auth.setDefaultSubscriptionService(product.serviceName, product.publicId, function(error, response) {
                    if (!error && response) {
                        console.info('Successfully set default service.');
                        loadSpeakEasy();
                    } else {
                        console.error('Service subscription details retrieval failed: ', error);
                    }

                });

            } else {
                console.error('Authentication failed: ', error);
            }
        });
    }

    function populateSubscriptionServices(services) {
        var publicIds = Object.keys(services);
        for (var val in services) {
            if(services.hasOwnProperty(val)) {
                for (var serviceName in services[val]) {
                    if(services[val].hasOwnProperty(serviceName)) {
                        return {
                            publicId: val,
                            serviceName: services[val][serviceName]
                        };
                    }
                }
            }
        }
    }

    function loadSpeakEasy() {
        Ctl.load('SpeakEasy', '0.1.4', function(err, speakEasy) {
            if (err) {
                console.log('Error loading SpeakEasy', err);
            } else {
                console.log('Running SpeakEasy v' + speakEasy.version());
                setupSpeakEasy(speakEasy);
                makeCall(speakEasy);
                // handleIncomingCall(speakEasy);
            }
        });
    }

    function setupSpeakEasy(speakEasy) {
        speakEasy.CallManager.setup({
            localVideoContainer: 'localVideo',
            remoteVideoContainer: 'remoteVideo'
        });

        var startVideoBtn = document.getElementById('startVideoBtn');
        var stopVideoBtn = document.getElementById('stopVideoBtn');

        startVideoBtn.addEventListener('click', function (e) {
            var currentCall = speakEasy.CallManager.getCurrentCall();
            currentCall.startVideoSend (
               function() {
                   console.log('Video is started!');
               },
               function() {
                   console.log("Video couldn't be started!");
               }
            );
        });

        stopVideoBtn.addEventListener('click', function (e) {
            var currentCall = speakEasy.CallManager.getCurrentCall();
            currentCall.stopVideoSend(
               function() {
                   console.log('Video is stopped!');
               },
               function() {
                   console.log("Video couldn't be stopped!");
               }
            );
        });

    }

    function makeCall(speakEasy) {
        speakEasy.CallManager.createCall('3183601227', true, function(call) {
            attachCallListeners(call);
        }, function() {
            console.log('Make new call failed!');
        });
    }

    function attachCallListeners(call) {

        call.on('CALL_RINGING', function() {
            console.log('Ringing!');
        });

        call.on('CALL_STARTED', function() {
            console.log('Call is started!');
        });

        call.on('CALL_ENDED', function() {
            console.log('Call was ended on other side!');
        });

        call.on('CALL_HELD', function() {
            console.log('Call is held!');
        });

        call.on('CALL_REMOTE_HELD', function() {
            console.log('Call was held on other side!');
        });

        call.on('CALL_REJECTED', function() {
            console.log('Call was rejected!');
        });

    }

    function handleIncomingCall(speakEasy) {

        speakEasy.CallManager.onCallReceived = function (call) {

            attachCallListeners(call);

            var callerInfo = call.getCallerInfo();

            var r = confirm('Incoming call from '+ callerInfo.name +'(' + callerInfo.number + ')! Would you like to answer?');
            if (r === true) {
                call.answer(function() {
                    console.log('Call is answered!');
                }, function() {
                    console.log("Call couldn't be answered!");
                });
            } else {
                call.reject(function() {
                    console.log("Call has been successfully rejected!");
                }, function() {
                    console.log("Call couldn't be rejected!");
                });
            }
        };
    }

});
